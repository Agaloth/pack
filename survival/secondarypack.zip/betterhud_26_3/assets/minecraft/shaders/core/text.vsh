#version 330
#extension GL_ARB_separate_shader_objects : require

#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

// GUI and see-through text render at full brightness (vanilla does NOT sample
// the lightmap for these). Only in-world text is lit by the lightmap.
#if defined(IS_GUI) || defined(IS_SEE_THROUGH)
#define LIGHTMAP vec4(1.0)
#else
#define LIGHTMAP sample_lightmap(Sampler2, UV2)
#endif

bool range(float t, float m1, float m2) { return t >= m1 && t <= m2; }
bool range(vec2 t, vec2 m1, vec2 m2) { return range(t.x, m1.x, m2.x) && range(t.y, m1.y, m2.y); }
bool range(vec3 t, vec3 m1, vec3 m2) { return range(t.x, m1.x, m2.x) && range(t.y, m1.y, m2.y) && range(t.z, m1.z, m2.z); }

void main() {
    vec3 pos = Position;
    vec2 ui = ceil(2.0 / vec2(ProjMat[0][0], -ProjMat[1][1]));
    vec3 color = Color.xyz;
    vertexColor = Color * LIGHTMAP;

    if (pos.y >= ui.y && ProjMat[3].x == -1.0) {
        int bit = int(pos.y) >> HEIGHT_BIT;
        if (((bit >> MAX_BIT) & 1) == 1) {
            int id = bit - (1 << MAX_BIT);
            pos.x -= 0.5 * ui.x;
            pos.y -= float((bit << HEIGHT_BIT) + ADD_OFFSET + DEFAULT_OFFSET);
            float xGui = 0.0;
            float yGui = 0.0;
            float layer = 0.0;
            float opacity = 1.0;
            int property = 0;
            switch (id) {
                case 1: break;
                case 2: layer = 1.0; break;
                case 3: layer = 1.0; break;
                case 4: layer = 2.0; break;
                case 5: layer = 2.0; break;
                case 6: yGui = ui.y; layer = 1.0; break;
                case 7: yGui = ui.y; layer = 4.0; break;
                case 8: xGui = ui.x * 0.5; layer = 1.0; break;
                case 9: xGui = ui.x * 0.5; layer = 4.0; break;
                case 10: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 1.0; break;
                case 11: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 2.0; break;
                case 12: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 3.0; break;
                case 13: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 4.0; break;
                case 14: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 5.0; break;
                case 15: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 6.0; break;
                case 16: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 10.0; break;
                case 17: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 11.0; break;
                case 18: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 12.0; break;
                case 19: xGui = ui.x * 0.5; yGui = ui.y * 0.99; layer = 13.0; break;
                case 20: xGui = ui.x * 0.5; yGui = ui.y; layer = 1.0; break;
                case 21: xGui = ui.x * 0.5; yGui = ui.y; layer = 2.0; break;
                case 22: xGui = ui.x * 0.5; yGui = ui.y; layer = 3.0; break;
                case 23: xGui = ui.x; layer = 1.0; break;
                case 24: xGui = ui.x; layer = 2.0; break;
                case 25: xGui = ui.x; layer = 4.0; break;
                case 26: xGui = ui.x; layer = 5.0; break;
                case 27: xGui = ui.x; yGui = ui.y; layer = 1.0; break;
                case 28: xGui = ui.x; yGui = ui.y; layer = 4.0; break;
            }

            vertexColor = Color * LIGHTMAP * vec4(1.0, 1.0, 1.0, opacity);

            // Wavy text
            if ((property & 1) > 0) {
                pos.y += 4.0 * sin((GameTime * 1200.0 + pos.x / ui.x) * 3.1415 * 2.0);
            }
            // Rainbow text
            if ((property & 2) > 0) {
                int hash = int(pos.x) * int(pos.y);
                float time = GameTime * 1200.0;
                hash = 31 * (hash + int(vertexColor.x + time));
                float r = float(hash % 224 + 32) / 255.0;
                hash = 31 * (hash + int(vertexColor.y + time));
                float g = float(hash % 224 + 32) / 255.0;
                hash = 31 * (hash + int(vertexColor.z + time));
                float b = float(hash % 224 + 32) / 255.0;
                float maxValue = max(max(r, g), b);
                vertexColor = vec4(pow(r / maxValue, 3.0), pow(g / maxValue, 3.0), pow(b / maxValue, 3.0), vertexColor.w);
            }
            // Shimmer text
            if ((property & 4) > 0) {
                int hash = int(pos.x) * int(pos.y);
                float time = GameTime * 1200.0;
                hash = 31 * (hash + int(vertexColor.x + time));
                float r = vertexColor.x + float(hash % 64) / 255.0;
                hash = 31 * (hash + int(vertexColor.y + time));
                float g = vertexColor.y + float(hash % 64) / 255.0;
                hash = 31 * (hash + int(vertexColor.z + time));
                float b = vertexColor.z + float(hash % 64) / 255.0;
                vertexColor = vec4(r, g, b, vertexColor.w);
            }

            pos.x += xGui;
            pos.y += yGui;
            pos.z += layer;
        }
    } else {
        // Hide the vanilla XP level number
        vec3 exp = vec3(128.0, 255.0, 32.0);
        if (ProjMat[3].x == -1.0
            && range(pos.y, ui.y - 60.0, ui.y - 20.0)
            && range(pos.x, ui.x / 2.0 - 60.0, ui.x / 2.0 + 60.0)
            && (range(color, exp / 256.0, exp / 254.0) || color == vec3(0.0))) {
            vertexColor = vec4(0.0);
        }
    }

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
#endif
    texCoord0 = UV0;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
